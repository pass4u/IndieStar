//
//  ViewController.m
//  ios_same_project
//
//  Created by hyop seung on 02/05/2017.
//  Copyright © 2017 SuperStarGame. All rights reserved.
//

#import "ViewController.h"
#import "IndieStar.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 200, 50)];
    
    // Set the text property of the label
    label.text = @"Hello again!";
    
    // Add the label object to the view
    [self.view addSubview:label];
    
    // 유니티등을 사용하지 않고 게임뷰의 viewcontroller를 직접 지정해야 하는 경우 initSDK 사용
    // 그렇지 않은경우는 initSDK 는 생략가능
    [IndieStar initSDK: self];
    
    //apple id 와 inidestar sdk key 그리고 ios의 번들명 을 입력
    //key 와 번들명은 꼭 indiestar 측에서 발급받은 값으로 사용
    //표시할 배너가 없으면 창이 뜨지 않습니다.
    [[IndieStar sharedInstance] IndieStarStart:@"12345678"  indiestar_id:@"RHh6Ciy5StHdWxcKQ" package_name:@"com.slowpuppy.btth.ios"];
    
    //팝업호출
    [[IndieStar sharedInstance] IndieStarAd];
    
    //심플배너호출
    [[IndieStar sharedInstance] IndieStarMoreGameSimple];
    
    //게임 공지사항 호출
    [[IndieStar sharedInstance]IndieStarGameNotice];
    
    //공유하기 view 호출
    //indiestar hearder gameshare parameter strkey값은 getshareurl의 return value
    [[IndieStar sharedInstance] GameShare:[NSString stringWithFormat:@"%@", @"connect-web.superstar-game.tv/share/click/IOS?key=asdfasdfasdf"]];
    
    //공유하기 URL 받기
    //indiestar header getshareurl parameter aos_pack_name = com.slowpuppy.~~~~
    //ios_apple_id = 124123123 숫자
    [[IndieStar sharedInstance] GetShareUrl:[NSString stringWithFormat:@"%@", @"com.slowpuppy.btth"] :[NSString stringWithFormat:@"%@", @"12345678"]];
    
    //게임내에서 원하는 포인트만큼 차감
    //indiestar header consume parameter strkey = getshareurl return value에서 문자열 분리하는 함수로
    //받아올수 있다, inum 은 원하는 포인트 차감 할 개수
    //return value = -1 : 구매실패 그 외에 양의 정수가 리턴될때는 구매후 남은 total의 갯수
    [[IndieStar sharedInstance] Consume:[NSString stringWithFormat:@"%@", @"key value"] : 1];
    
    //today,total 호출
    //indiestar header GetBalance parameter strkey = getshareurl return value에서 문자열 분리하는 함수로
    //받아올수 있다
    //return value = "today,toatl" ','로 문자열 분리 해서 받아올수 있다
    [[IndieStar sharedInstance] GetBalance:[NSString stringWithFormat:@"%@", @"key value"]];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
