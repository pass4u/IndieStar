//
//  ViewController.m
//  ios_same_project
//
//  Created by hyop seung on 02/05/2017.
//  Copyright © 2017 SuperStarGame. All rights reserved.
//

#import "ViewController.h"
#import "IndieStar.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 200, 50)];
    
    // Set the text property of the label
    label.text = @"Hello again!";
    
    // Add the label object to the view
    [self.view addSubview:label];
    
    
    // 유니티등을 사용하지 않고 게임뷰의 viewcontroller를 직접 지정해야 하는 경우 initSDK 사용
    // 그렇지 않은경우는 initSDK 는 생략가능
    [IndieStar initSDK: self];
    
    //apple id 와 inidestar sdk key 그리고 ios의 번들명 을 입력
    //key 와 번들명은 꼭 indiestar 측에서 발급받은 값으로 사용
    [[IndieStar sharedInstance] IndieStarStart:@"12345678"  indiestar_id:@"RHh6Ciy5StHdWxcKQ" package_name:@"com.slowpuppy.samplegame.ios"];
    
    //팝업호출
    [[IndieStar sharedInstance] IndieStarAd];
    
    //심플배너호출
    //[[IndieStar sharedInstance] IndieStarMoreGameSimple];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
